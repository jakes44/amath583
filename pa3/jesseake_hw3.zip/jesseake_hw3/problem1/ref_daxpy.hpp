#ifndef JESSEAKE_REFDAXPY_HPP
#define JESSEAKE_REFDAXPY_HPP

#include <vector>

void daxpy(double a, const std::vector<double>& x, std::vector<double>& y);

#endif